package mate.academy.internetshop;

import mate.academy.internetshop.lib.Injector;
import mate.academy.internetshop.model.Order;
import mate.academy.internetshop.model.Product;
import mate.academy.internetshop.model.ShoppingCart;
import mate.academy.internetshop.model.User;
import mate.academy.internetshop.service.OrderService;
import mate.academy.internetshop.service.ProductService;
import mate.academy.internetshop.service.ShoppingCartService;
import mate.academy.internetshop.service.UserService;

public class Main {
    private static Injector injector = Injector.getInstance("mate.academy.internetshop");

    public static void main(String[] args) {
        final ProductService productService =
                (ProductService) injector.getInstance(ProductService.class);
        final UserService userService =
                (UserService) injector.getInstance(UserService.class);
        final ShoppingCartService shoppingCartService =
                (ShoppingCartService) injector.getInstance(ShoppingCartService.class);
        final OrderService orderService =
                (OrderService) injector.getInstance(OrderService.class);
        Product flowers = new Product("flowers", 250.00);
        Product boots = new Product("boots", 1500.00);
        Product puppy = new Product("black puppy", 1000.00);

        productService.create(flowers);
        productService.create(boots);
        productService.create(puppy);

        System.out.println(productService.get(boots.getId()));
        System.out.println(productService.getAll());

        Product beer = new Product("beer", 20.00);
        System.out.println(productService.delete(beer.getId()));

        puppy.setName("white puppy");
        productService.update(puppy);
        System.out.println(productService.getAll());
        User arthur = new User("Arthur", "Arcana Lord", "123123123");
        User peter = new User("Peter", "Chris Wilson", "987654321");
        userService.create(arthur);
        userService.create(peter);
        System.out.println(userService.get(arthur.getId()));
        System.out.println(userService.getAll());

        arthur.setLogin("Galahat");
        userService.update(arthur);
        System.out.println(userService.get(arthur.getId()));

        userService.delete(peter.getId());
        System.out.println(userService.getAll());

        ShoppingCart arthurCart = shoppingCartService.getByUserId(arthur.getId());
        shoppingCartService.addProduct(arthurCart, puppy);
        shoppingCartService.addProduct(arthurCart, flowers);
        shoppingCartService.addProduct(arthurCart, boots);
        System.out.println(shoppingCartService.getAllProducts(arthurCart));

        shoppingCartService.deleteProduct(arthurCart, boots);
        System.out.println(shoppingCartService.getByUserId(arthur.getId()));

        Order arthurOrder = orderService.completeOrder(
                shoppingCartService.getAllProducts(arthurCart), arthur);
        System.out.println(shoppingCartService.getByUserId(arthur.getId()));

        System.out.println(orderService.get(arthurOrder.getId()));
        System.out.println(orderService.getUserOrders(arthur));

        userService.create(peter);
        productService.create(beer);
        ShoppingCart peterCart = shoppingCartService.getByUserId(peter.getId());
        shoppingCartService.addProduct(peterCart, beer);
        Order peterOrder = orderService.completeOrder(
                shoppingCartService.getAllProducts(peterCart), peter);

        System.out.println(orderService.getAll());
        orderService.delete(peterOrder.getId());
        System.out.println(orderService.getAll());



//        productService.create(new Product("two noodles", 19.95));
//        productService.create(new Product("three noodles", 29.95));
//        productService.create(new Product("whole set of noodles", 35.90));
//
//        productService.getAll().forEach(it -> System.out.println(it.toString()));
//
//        Product product1 = productService.get(2L);
//        System.out.println(product1.toString());
//
//        productService.delete(2L);
//        productService.update(productService.get(3L));
//
//        productService.getAll().forEach(it -> System.out.println(it.toString()));

    }
}
